!\bin\bash



echo("Enter choice")
echo("1.Add Record ")
echo("2.Search Record")
echo("3.Delete Record")
echo("4.Show All Records")

choice = $1

while [ choice -gt 0]
do
   switch(choice){
    case 1:

    case 2:

    case 3:

    case 4:
    
   }

